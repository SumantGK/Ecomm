export const ADD_TO_CART = "ADD_TO_CART";
export const REMOVE_FROM_CART = "REMOVE_FROM_CART";
export const FILTER = "FILTER";
export const CART_COUNT = "CART_COUNT";
export const CURRENCY = "CURRENCY";
export const COLOR = "COLOR";
