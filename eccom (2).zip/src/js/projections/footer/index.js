const footer = () => {
  return (
    <>
      <div className="footer">@copyrights</div>
    </>
  );
};
export default footer;
