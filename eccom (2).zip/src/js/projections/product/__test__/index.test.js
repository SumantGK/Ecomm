import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import Product from "../index";
import "@testing-library/jest-dom/extend-expect";
